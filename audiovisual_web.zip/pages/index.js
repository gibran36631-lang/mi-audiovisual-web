import Landing from '../src/Landing'
export default function Home() { return <Landing /> }