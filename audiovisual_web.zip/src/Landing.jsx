// Código React que generamos en la demo
